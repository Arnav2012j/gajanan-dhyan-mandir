import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const quickLinks = [
  { label: 'देणगी योजना', href: '#donation' },
  { label: 'सेवा प्रकल्प', href: '#activities' },
  { label: 'गॅलरी', href: '#gallery' },
  { label: 'संपर्क', href: '#contact' },
];

export default function Footer() {
  const footerRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        footerRef.current,
        { opacity: 0 },
        {
          opacity: 1,
          duration: 0.6,
          scrollTrigger: {
            trigger: footerRef.current,
            start: 'top 90%',
            toggleActions: 'play none none none',
          },
        }
      );
    }, footerRef);

    return () => ctx.revert();
  }, []);

  const handleNavClick = (href: string) => {
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer
      ref={footerRef}
      className="py-12 px-4 md:px-8"
      style={{ backgroundColor: '#6A040F' }}
    >
      <div className="max-w-6xl mx-auto">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          {/* Column 1 - Trust info */}
          <div>
            <p className="text-lg font-bold mb-2" style={{ color: '#FFF8E7' }}>
              श्री संत गजानन महाराज सेवा ट्रस्ट
            </p>
            <p style={{ fontSize: '0.9rem', color: 'rgba(255, 248, 231, 0.6)' }}>
              सेवा हीच साधना
            </p>
          </div>

          {/* Column 2 - Quick links */}
          <div>
            <p className="font-semibold mb-3" style={{ color: '#FFB703', fontSize: '0.95rem' }}>
              दुवे
            </p>
            <div className="space-y-2">
              {quickLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={(e) => {
                    e.preventDefault();
                    handleNavClick(link.href);
                  }}
                  className="block transition-colors duration-200 hover:text-[#FFB703]"
                  style={{ color: '#FFF8E7', fontSize: '0.95rem' }}
                >
                  {link.label}
                </a>
              ))}
            </div>
          </div>

          {/* Column 3 - Legal */}
          <div>
            <p className="font-semibold mb-3" style={{ color: '#FFB703', fontSize: '0.95rem' }}>
              कायदेशीर
            </p>
            <div className="space-y-2">
              <p style={{ fontSize: '0.9rem', color: 'rgba(255, 248, 231, 0.7)' }}>
                कर मुक्त देणगी (80G)
              </p>
              <p style={{ fontSize: '0.9rem', color: 'rgba(255, 248, 231, 0.7)' }}>
                12A परवाना
              </p>
              <p style={{ fontSize: '0.9rem', color: 'rgba(255, 248, 231, 0.7)' }}>
                पारदर्शकता अहवाल
              </p>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="w-full h-px mb-6" style={{ backgroundColor: 'rgba(255, 183, 3, 0.2)' }} />

        {/* Bottom */}
        <p className="text-center mb-2" style={{ fontSize: '0.9rem', color: 'rgba(255, 248, 231, 0.5)' }}>
          &copy; २०२५ श्री संत गजानन महाराज सेवा ट्रस्ट. सर्व हक्क राखीव.
        </p>
        <p
          className="text-center italic"
          style={{ fontSize: '0.85rem', color: 'rgba(255, 183, 3, 0.6)' }}
        >
          संकल्पनेतून साकार — श्री गजानन महाराजांच्या कृपेने
        </p>
      </div>
    </footer>
  );
}
