import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { MapPin, Phone, MessageCircle, Mail, Copy, Check } from 'lucide-react';
import { useState } from 'react';

gsap.registerPlugin(ScrollTrigger);

export default function Contact() {
  const sectionRef = useRef<HTMLElement>(null);
  const leftRef = useRef<HTMLDivElement>(null);
  const rightRef = useRef<HTMLDivElement>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        leftRef.current,
        { opacity: 0, x: -40 },
        {
          opacity: 1,
          x: 0,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );

      gsap.fromTo(
        rightRef.current,
        { opacity: 0, x: 40 },
        {
          opacity: 1,
          x: 0,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const handleCopyUPI = () => {
    navigator.clipboard.writeText('gajananseva@upi').then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <section
      id="contact"
      ref={sectionRef}
      className="py-20 px-4 md:px-8"
      style={{
        background: 'linear-gradient(180deg, #FFFBF5 0%, #FFF3E0 100%)',
      }}
    >
      <div className="max-w-6xl mx-auto">
        <h2
          className="font-bold text-center leading-tight mb-12"
          style={{
            fontSize: 'clamp(1.6rem, 3.5vw, 2.4rem)',
            color: '#6A040F',
          }}
        >
          संपर्क साधा — सेवेत सहभागी व्हा
        </h2>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Left - Contact cards */}
          <div ref={leftRef} className="space-y-4">
            {/* Address */}
            <div
              className="p-6 rounded-2xl"
              style={{
                backgroundColor: '#FFFBF5',
                border: '1px solid rgba(244, 162, 97, 0.3)',
                boxShadow: '0 4px 12px rgba(232, 93, 4, 0.08)',
              }}
            >
              <div className="flex items-start gap-4">
                <MapPin size={28} style={{ color: '#E85D04', flexShrink: 0 }} />
                <div>
                  <h3 className="font-bold text-lg mb-1" style={{ color: '#2D1B00' }}>
                    पत्ता
                  </h3>
                  <p style={{ fontSize: '1.05rem', color: '#2D1B00', lineHeight: 1.7 }}>
                    श्री संत गजानन महाराज सेवा ट्रस्ट, महाराज वाडी, ता. शेगाव, जि. बुलढाणा, महाराष्ट्र — 444203
                  </p>
                </div>
              </div>
            </div>

            {/* Phone */}
            <div
              className="p-6 rounded-2xl"
              style={{
                backgroundColor: '#FFFBF5',
                border: '1px solid rgba(244, 162, 97, 0.3)',
                boxShadow: '0 4px 12px rgba(232, 93, 4, 0.08)',
              }}
            >
              <div className="flex items-start gap-4">
                <Phone size={28} style={{ color: '#E85D04', flexShrink: 0 }} />
                <div>
                  <h3 className="font-bold text-lg mb-1" style={{ color: '#2D1B00' }}>
                    दूरध्वनी
                  </h3>
                  <p style={{ fontSize: '1.05rem', color: '#2D1B00' }}>
                    +91 98765 43210, +91 98765 43211
                  </p>
                  <p style={{ fontSize: '0.9rem', color: '#8B6914' }}>
                    सकाळी ८ ते रात्री ८
                  </p>
                </div>
              </div>
            </div>

            {/* WhatsApp */}
            <div
              className="p-6 rounded-2xl"
              style={{
                backgroundColor: '#FFFBF5',
                border: '1px solid rgba(244, 162, 97, 0.3)',
                boxShadow: '0 4px 12px rgba(232, 93, 4, 0.08)',
              }}
            >
              <div className="flex items-start gap-4">
                <MessageCircle size={28} style={{ color: '#2D6A4F', flexShrink: 0 }} />
                <div className="w-full">
                  <h3 className="font-bold text-lg mb-1" style={{ color: '#2D1B00' }}>
                    व्हॉट्सअ‍ॅप
                  </h3>
                  <p style={{ fontSize: '1.05rem', color: '#2D1B00' }}>
                    +91 98765 43210 (व्हॉट्सअ‍ॅप मेसेज / कॉल)
                  </p>
                  <button
                    className="mt-3 w-full py-3 rounded-full text-white font-semibold transition-all duration-250 hover:opacity-90 flex items-center justify-center gap-2"
                    style={{ backgroundColor: '#2D6A4F' }}
                    onClick={() => window.open('https://wa.me/919876543210', '_blank')}
                  >
                    <MessageCircle size={20} />
                    व्हॉट्सअ‍ॅपवर संपर्क करा
                  </button>
                </div>
              </div>
            </div>

            {/* Email */}
            <div
              className="p-6 rounded-2xl"
              style={{
                backgroundColor: '#FFFBF5',
                border: '1px solid rgba(244, 162, 97, 0.3)',
                boxShadow: '0 4px 12px rgba(232, 93, 4, 0.08)',
              }}
            >
              <div className="flex items-start gap-4">
                <Mail size={28} style={{ color: '#E85D04', flexShrink: 0 }} />
                <div>
                  <h3 className="font-bold text-lg mb-1" style={{ color: '#2D1B00' }}>
                    ईमेल
                  </h3>
                  <p style={{ fontSize: '1.05rem', color: '#2D1B00' }}>
                    seva@gajananmaharajtrust.org
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Right - Bank details with image */}
          <div ref={rightRef}>
            <div
              className="rounded-2xl overflow-hidden"
              style={{
                backgroundColor: '#FFFBF5',
                border: '2px solid rgba(244, 162, 97, 0.3)',
                boxShadow: '0 4px 12px rgba(232, 93, 4, 0.08)',
              }}
            >
              <img
                src="/images/contact-location.jpg"
                alt="मंदिर"
                className="w-full h-48 md:h-56 object-cover"
              />
              <div className="p-6 md:p-8">
                <h3 className="font-bold text-xl mb-4" style={{ color: '#D00000' }}>
                  देणगी तपशील
                </h3>
                <div className="space-y-3" style={{ fontSize: '1.05rem', color: '#2D1B00', lineHeight: 1.7 }}>
                  <p><span style={{ color: '#8B6914' }}>बँक:</span> स्टेट बँक ऑफ इंडिया</p>
                  <p><span style={{ color: '#8B6914' }}>खातेधारक:</span> श्री संत गजानन महाराज सेवा ट्रस्ट</p>
                  <p><span style={{ color: '#8B6914' }}>खाते क्रमांक:</span> 12345678901</p>
                  <p><span style={{ color: '#8B6914' }}>IFSC:</span> SBIN0001234</p>
                  <div className="flex items-center gap-2">
                    <p><span style={{ color: '#8B6914' }}>UPI:</span> gajananseva@upi</p>
                    <button
                      onClick={handleCopyUPI}
                      className="p-1 rounded transition-colors hover:bg-[#FFF3E0]"
                      title="Copy UPI ID"
                    >
                      {copied ? <Check size={16} style={{ color: '#2D6A4F' }} /> : <Copy size={16} style={{ color: '#8B6914' }} />}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
