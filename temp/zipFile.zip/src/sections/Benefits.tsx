import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Sparkles, Flame, Users, CircleDot } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const benefits = [
  {
    icon: Sparkles,
    text: 'दानाने पापनाश होतो — \'दानं सर्वविनाशनम्\' असे शास्त्र सांगते. दान हे सर्व पापांचे निवारण आहे.',
  },
  {
    icon: Flame,
    text: 'अग्नीने दान दिलेले धान्य शुद्ध करतो. अन्नदान हे सर्व दानांमध्ये उत्तम मानले जाते.',
  },
  {
    icon: Users,
    text: 'गरीबांना अन्न देणे म्हणजे देवाला अन्न दिल्यासारखे. \'अन्नदानं महादानं\' — अन्नदान हे महादान आहे.',
  },
  {
    icon: CircleDot,
    text: 'सेवेने मन शुद्ध होते, समाज सुधारतो व परिवारात सुख-समृद्धी नांदते.',
  },
];

export default function Benefits() {
  const sectionRef = useRef<HTMLElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const itemsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        imageRef.current,
        { opacity: 0, scale: 0.85, rotation: -5 },
        {
          opacity: 1,
          scale: 1,
          rotation: 0,
          duration: 1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );

      if (itemsRef.current) {
        gsap.fromTo(
          itemsRef.current.children,
          { opacity: 0, x: 30 },
          {
            opacity: 1,
            x: 0,
            duration: 0.7,
            stagger: 0.15,
            delay: 0.3,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: sectionRef.current,
              start: 'top 80%',
              toggleActions: 'play none none none',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="py-20 px-4 md:px-8"
      style={{
        background: 'linear-gradient(135deg, #6A040F 0%, #9D0208 50%, #D00000 100%)',
      }}
    >
      <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-12 items-center">
        {/* Left - Circular Image */}
        <div className="flex justify-center">
          <div
            ref={imageRef}
            className="relative"
            style={{
              width: 'clamp(260px, 30vw, 360px)',
              height: 'clamp(260px, 30vw, 360px)',
            }}
          >
            <div
              className="w-full h-full rounded-full overflow-hidden circular-frame"
              style={{
                border: '5px solid #FFB703',
                boxShadow: '0 0 60px rgba(255, 183, 3, 0.3)',
              }}
            >
              <img
                src="/images/benefits-section.jpg"
                alt="आरती सेवा"
                className="w-full h-full object-cover"
              />
            </div>
            {/* Decorative dots */}
            <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-3 h-3 rounded-full" style={{ backgroundColor: '#FFB703' }} />
            <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-3 h-3 rounded-full" style={{ backgroundColor: '#FFB703' }} />
            <div className="absolute top-1/2 -left-2 -translate-y-1/2 w-3 h-3 rounded-full" style={{ backgroundColor: '#FFB703' }} />
            <div className="absolute top-1/2 -right-2 -translate-y-1/2 w-3 h-3 rounded-full" style={{ backgroundColor: '#FFB703' }} />
          </div>
        </div>

        {/* Right - Benefits text */}
        <div ref={itemsRef}>
          <h2
            className="font-bold leading-tight mb-8"
            style={{
              fontSize: 'clamp(1.6rem, 3.5vw, 2.4rem)',
              color: '#FFF8E7',
            }}
          >
            दानाचे महत्त्व — धर्म, अर्थ आणि मोक्ष
          </h2>

          <div className="space-y-0">
            {benefits.map((benefit, idx) => {
              const Icon = benefit.icon;
              return (
                <div
                  key={idx}
                  className="py-5"
                  style={{
                    borderBottom:
                      idx < benefits.length - 1
                        ? '1px solid rgba(255, 184, 3, 0.2)'
                        : 'none',
                  }}
                >
                  <div className="flex gap-4 items-start">
                    <Icon size={24} style={{ color: '#FFB703', flexShrink: 0, marginTop: '4px' }} />
                    <p
                      style={{
                        fontSize: '1.05rem',
                        color: '#FFF8E7',
                        lineHeight: 1.8,
                      }}
                    >
                      {benefit.text}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
