import { useEffect, useRef } from 'react';
import { useNavigate } from 'react-router';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { HandHeart, Heart, CircleDot, Wheat } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const donationCards = [
  {
    icon: HandHeart,
    price: '₹1100',
    title: 'सकाळचे अन्नदान',
    description: 'गरीब व जरुरीमंदांसाठी सकाळचा नैवेद्य व जेवण.',
  },
  {
    icon: Heart,
    price: '₹2100',
    title: 'संध्याकाळचे अन्नदान',
    description: 'संध्याकाळी गरजू लोकांना भोजन व नैवेद्य सेवा.',
  },
  {
    icon: CircleDot,
    price: '₹5501',
    title: 'गुरुदक्षिणा सेवा',
    description: 'गुरूचरणी दक्षिणा — विद्यार्थ्यांना शिष्यवृत्ती व शिक्षण साहित्य.',
  },
  {
    icon: Wheat,
    price: '₹11000',
    title: 'महादान योजना',
    description: 'विशेष देणगी — मंदिर विकास, गोशाळा व विद्यार्थी गृह.',
  },
];

export default function DonationPlans() {
  const navigate = useNavigate();
  const sectionRef = useRef<HTMLElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);
  const specialRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        specialRef.current,
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );

      if (cardsRef.current) {
        gsap.fromTo(
          cardsRef.current.children,
          { opacity: 0, scale: 0.9 },
          {
            opacity: 1,
            scale: 1,
            duration: 0.6,
            stagger: 0.12,
            ease: 'back.out(1.7)',
            scrollTrigger: {
              trigger: cardsRef.current,
              start: 'top 85%',
              toggleActions: 'play none none none',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="donation"
      ref={sectionRef}
      className="py-20 px-4 md:px-8"
      style={{
        background: 'linear-gradient(135deg, #FFF3E0 0%, #FFE4C4 50%, #FFDAB9 100%)',
      }}
    >
      {/* Subtle temple pattern watermark */}
      <div
        className="absolute inset-0 opacity-[0.03] pointer-events-none"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M30 5 L35 20 L45 15 L50 30 L60 25 L55 40 L60 55 L30 55 L0 55 L5 40 L0 25 L10 30 L15 15 L25 20 Z' fill='%23E85D04'/%3E%3C/svg%3E")`,
          backgroundSize: '120px 120px',
        }}
      />

      <div className="max-w-6xl mx-auto relative z-10">
        <h2
          className="font-bold text-center leading-tight mb-3"
          style={{
            fontSize: 'clamp(1.6rem, 3.5vw, 2.4rem)',
            color: '#6A040F',
          }}
        >
          देणगी योजना — अन्नदान, गुरुदक्षिणा व विशेष सेवा
        </h2>
        <p className="text-center mb-10" style={{ fontSize: '0.9rem', color: '#8B6914' }}>
          आपल्या श्रद्धेनुसार देणगी निवडा. प्रत्येक देणगी ही करमुक्त आहे व 80G प्रमाणपत्र मिळेल.
        </p>

        {/* Special highlighted box */}
        <div
          ref={specialRef}
          className="mb-10 p-7 md:p-8 rounded-2xl text-center"
          style={{
            border: '3px solid #E85D04',
            background: 'linear-gradient(135deg, #FFF8E7, #FFE4C4)',
          }}
        >
          <p className="text-sm font-semibold uppercase tracking-wider mb-2" style={{ color: '#E85D04' }}>
            विशेष अन्नदान योजना
          </p>
          <p className="font-extrabold" style={{ fontSize: '2.5rem', color: '#D00000' }}>
            ₹5100
          </p>
          <p className="mt-3 max-w-2xl mx-auto" style={{ fontSize: '1.05rem', color: '#2D1B00', lineHeight: 1.7 }}>
            संपूर्ण अन्नदान सेवा — एका संपूर्ण दिवसाचे अन्नदान (सकाळी व संध्याकाळी) + गायींसाठी गवत व चारा + वृद्धांना वस्त्रदान
          </p>
          <button
            onClick={() => navigate('/donate')}
            className="mt-5 px-8 py-3 rounded-full text-white font-semibold transition-all duration-250 hover:-translate-y-0.5"
            style={{
              backgroundColor: '#E85D04',
              boxShadow: '0 4px 20px rgba(232, 93, 4, 0.3)',
            }}
          >
            देणगी द्या
          </button>
        </div>

        {/* Donation cards grid */}
        <div ref={cardsRef} className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {donationCards.map((card) => {
            const Icon = card.icon;
            return (
              <div
                key={card.price}
                className="p-7 rounded-2xl text-center transition-all duration-300 hover:-translate-y-1 cursor-pointer"
                style={{
                  backgroundColor: '#FFFBF5',
                  border: '2px solid #F4A261',
                  boxShadow: '0 4px 16px rgba(232, 93, 4, 0.1)',
                }}
                onMouseEnter={(e) => {
                  const el = e.currentTarget;
                  el.style.borderColor = '#E85D04';
                  el.style.boxShadow = '0 8px 24px rgba(232, 93, 4, 0.2)';
                }}
                onMouseLeave={(e) => {
                  const el = e.currentTarget;
                  el.style.borderColor = '#F4A261';
                  el.style.boxShadow = '0 4px 16px rgba(232, 93, 4, 0.1)';
                }}
              >
                <div className="flex justify-center mb-3">
                  <Icon size={40} style={{ color: '#FFB703' }} />
                </div>
                <p className="font-extrabold mb-1" style={{ fontSize: '1.8rem', color: '#D00000' }}>
                  {card.price}
                </p>
                <p className="font-bold text-lg mb-2" style={{ color: '#2D1B00' }}>
                  {card.title}
                </p>
                <p style={{ fontSize: '0.9rem', color: '#8B6914', lineHeight: 1.6 }}>
                  {card.description}
                </p>
              </div>
            );
          })}
        </div>

        <p className="text-center mt-8" style={{ fontSize: '0.9rem', color: '#8B6914' }}>
          देणगी ऑनलाइन / बँक ट्रान्सफर / चेक / रोख स्वीकारली जाते.
        </p>
      </div>
    </section>
  );
}
