import { useNavigate } from 'react-router';
import { ArrowLeft, Smartphone, Building2, MessageCircle } from 'lucide-react';

export default function Donate() {
  const navigate = useNavigate();

  return (
    <div
      className="min-h-screen py-8 px-4"
      style={{
        background: 'radial-gradient(ellipse at top, #FFF8E7 0%, #FFE4C4 60%, #F4A261 100%)',
      }}
    >
      {/* Back button */}
      <button
        onClick={() => navigate('/')}
        className="flex items-center gap-2 mb-8 font-semibold transition-all duration-200 hover:-translate-x-1"
        style={{ color: '#E85D04' }}
      >
        <ArrowLeft size={20} />
        मुख्य पृष्ठावर परत जा
      </button>

      {/* Header */}
      <div className="text-center mb-10">
        <p className="text-3xl font-bold mb-1" style={{ color: '#D00000' }}>ॐ</p>
        <h1
          className="font-extrabold leading-tight mb-3"
          style={{ fontSize: 'clamp(1.8rem, 5vw, 3rem)', color: '#2D1B00' }}
        >
          देणगी पृष्ठ
        </h1>
        <p className="max-w-xl mx-auto leading-relaxed" style={{ color: '#8B6914', fontSize: '1.05rem' }}>
          आपली देणगी गरीब व जरुरीमंद बांधवांच्या जीवनात प्रकाश आणते.
          अन्नदान, वस्त्रदान व शिक्षणासाठी आपले सहकार्य अमूल्य आहे.
        </p>
        <div className="flex flex-col items-center gap-1 mt-4">
          <div style={{ width: '120px', height: '2px', backgroundColor: '#E85D04' }} />
          <div style={{ width: '80px', height: '1px', backgroundColor: '#F4A261' }} />
        </div>
      </div>

      <div className="max-w-2xl mx-auto flex flex-col gap-6">

        {/* UPI Section */}
        <div
          className="rounded-2xl p-6 text-center"
          style={{
            background: 'rgba(255,255,255,0.75)',
            border: '1.5px solid rgba(232,93,4,0.2)',
            boxShadow: '0 4px 24px rgba(232,93,4,0.08)',
          }}
        >
          <div className="flex items-center justify-center gap-2 mb-3">
            <Smartphone size={22} style={{ color: '#E85D04' }} />
            <h2 className="text-xl font-bold" style={{ color: '#2D1B00' }}>UPI / QR कोड द्वारे देणगी</h2>
          </div>
          <p className="mb-4 text-sm" style={{ color: '#8B6914' }}>
            खालील QR कोड स्कॅन करा किंवा UPI ID वापरा
          </p>

          {/* Placeholder QR */}
          <div
            className="mx-auto mb-4 rounded-xl flex items-center justify-center"
            style={{
              width: 160,
              height: 160,
              background: '#FFF3E0',
              border: '2px dashed #E85D04',
            }}
          >
            <div className="text-center">
              <div className="text-4xl mb-1">📱</div>
              <p className="text-xs font-semibold" style={{ color: '#E85D04' }}>QR कोड</p>
            </div>
          </div>

          <div
            className="inline-block px-5 py-2 rounded-full font-bold text-base tracking-wide"
            style={{ background: '#FFF3E0', color: '#E85D04', border: '1.5px solid #E85D04' }}
          >
            UPI ID: trust@upi
          </div>
        </div>

        {/* Bank Details Section */}
        <div
          className="rounded-2xl p-6"
          style={{
            background: 'rgba(255,255,255,0.75)',
            border: '1.5px solid rgba(232,93,4,0.2)',
            boxShadow: '0 4px 24px rgba(232,93,4,0.08)',
          }}
        >
          <div className="flex items-center gap-2 mb-4">
            <Building2 size={22} style={{ color: '#E85D04' }} />
            <h2 className="text-xl font-bold" style={{ color: '#2D1B00' }}>बँक तपशील</h2>
          </div>
          <div className="flex flex-col gap-3">
            {[
              { label: 'खाते नाव', value: 'श्री संत गजानन महाराज सेवा ट्रस्ट' },
              { label: 'खाते क्रमांक', value: '1234567890123456' },
              { label: 'IFSC कोड', value: 'SBIN0001234' },
              { label: 'बँकेचे नाव', value: 'स्टेट बँक ऑफ इंडिया' },
              { label: 'शाखा', value: 'शेगाव, महाराष्ट्र' },
            ].map((item) => (
              <div
                key={item.label}
                className="flex justify-between items-start py-2 border-b last:border-b-0"
                style={{ borderColor: 'rgba(232,93,4,0.12)' }}
              >
                <span className="font-semibold text-sm" style={{ color: '#8B6914' }}>{item.label}</span>
                <span className="font-bold text-sm text-right ml-4" style={{ color: '#2D1B00' }}>{item.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* WhatsApp / Contact */}
        <div
          className="rounded-2xl p-6 text-center"
          style={{
            background: 'rgba(255,255,255,0.75)',
            border: '1.5px solid rgba(232,93,4,0.2)',
            boxShadow: '0 4px 24px rgba(232,93,4,0.08)',
          }}
        >
          <div className="flex items-center justify-center gap-2 mb-2">
            <MessageCircle size={22} style={{ color: '#25D366' }} />
            <h2 className="text-xl font-bold" style={{ color: '#2D1B00' }}>संपर्क / WhatsApp</h2>
          </div>
          <p className="mb-4 text-sm" style={{ color: '#8B6914' }}>
            देणगीबाबत अधिक माहितीसाठी आम्हाला संपर्क करा
          </p>
          <a
            href="https://wa.me/919999999999"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-7 py-3 rounded-full text-white font-bold text-base transition-all duration-200 hover:-translate-y-0.5"
            style={{
              backgroundColor: '#25D366',
              boxShadow: '0 4px 16px rgba(37,211,102,0.3)',
            }}
          >
            <MessageCircle size={18} />
            WhatsApp वर संपर्क करा
          </a>
        </div>

        {/* Thank you note */}
        <div className="text-center py-4">
          <p className="font-semibold italic" style={{ color: '#D00000', fontSize: '1.05rem' }}>
            "जो देतो त्यालाच मिळते — सेवा हीच साधना"
          </p>
          <p className="text-sm mt-1" style={{ color: '#8B6914' }}>
            आपल्या उदार देणगीबद्दल मनःपूर्वक आभार 🙏
          </p>
        </div>

      </div>
    </div>
  );
}
